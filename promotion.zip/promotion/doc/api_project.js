define({
  "name": "促销系统API",
  "version": "0.2.0",
  "description": "促销系统API",
  "title": "促销系统API",
  "url": "http://localhost:8888",
  "sampleUrl": "http://localhost:8888",
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-07-02T14:17:20.936Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
